/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author olivas.hodei
 */
public class Laukizuzena implements Marrazgarria {

    private Puntua erpinBat;
    private Puntua kontrakoErpina;

    public Laukizuzena(Puntua erpinBat, Puntua kontrakoErpina) {
        this.erpinBat = erpinBat;
        this.kontrakoErpina = kontrakoErpina;
    }

    public Laukizuzena(int x1, int y1, int x2, int y2) {
         
    }

    public Puntua getErpinBat() {
        return erpinBat;
    }

    public Puntua getKontrakoErpina() {
        return kontrakoErpina;
    }

    public Puntua getLauErpinenArraya() {
        
       
        return kontrakoErpina;
    

    }
    public ArrayList<Puntua> getLauErpinenArrayLista() {
        return null;
        
    
        
    
        
        
        
    }

    @Override
    public String toString() {
        return '['+"(" + erpinBat + "," + kontrakoErpina + ')'+"(" + erpinBat + "," + kontrakoErpina + ')'+']';
    }

    @Override
    public void marraztu() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
