/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author olivas.hodei
 */
public class HiruLaukiSortuB {

    public static void main(String[] args) {

        Laukia l1 = new Laukia(7, 1);
        Laukia l2 = new Laukia(2, 2);
        Laukia l3 = new Laukia(2, 6);

        /*   System.out.println("Hiru lauki sortu dituzu: ");
        System.out.println("The width is: " + l1.getWidth());

        System.out.println("The height is: " + l1.getHeight());

        
        System.out.println("The width is: " + l2.getWidth());

        System.out.println("The height is: " + l2.getHeight());
        
        
        System.out.println("The width is: " + l3.getWidth());

        System.out.println("The height is: " + l3.getHeight());*/
         System.out.println("Hiru lauki sortu dituzu: ");
        System.out.println(l1 + " => "+ l1.getMota());
        System.out.println(l2+ " => "+ l2.getMota());
        System.out.println(l3+ " => "+ l3.getMota());

    }

}
