/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package probak1;
import model.Zatikia;
/**
 *
 * @author olivas.hodei
 */
public class BiderketaOndoDago {
    
    public static void main(String[] args) {
        
        
        Zatikia z1 = new Zatikia(5,7);
        Zatikia z2 = new Zatikia(7,6);
        
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
        
        
       //Zatikia z3 = Zatikia.biderkatu(z1, z2);
       // System.out.println(z3);
       //  Zatikia z3 = Zatikia.batu(z1, z2);
        
       //System.out.println(z3);
         
         
         
    }
    
}
